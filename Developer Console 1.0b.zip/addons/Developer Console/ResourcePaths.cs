﻿namespace hamsterbyte.DeveloperConsole;

public static class ResourcePaths{
    public const string Prefabs = "res://Prefabs";
    public const string Levels = "res://Levels";
}