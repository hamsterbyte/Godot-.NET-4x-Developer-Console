﻿namespace hamsterbyte.DeveloperConsole;

public interface ICanInitialize{
    public void Initialize();
    public bool TryInitialize();
}