﻿namespace hamsterbyte.DeveloperConsole;

public interface ICanReset{
    public void Reset();
    public bool TryReset();
}